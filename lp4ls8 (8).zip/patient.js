const firebaseConfig = {
  apiKey: "AIzaSyATCPtybCzqCHhj4jFFFsDnSaM1vZT1_Dg",
  authDomain: "dvista-4da17.firebaseapp.com",
  databaseURL: "https://dvista-4da17-default-rtdb.firebaseio.com",
  projectId: "dvista-4da17",
  storageBucket: "dvista-4da17.appspot.com",
  messagingSenderId: "301281279487",
  appId: "1:301281279487:web:55a443aefa5f8c4696fbca",
  measurementId: "G-ZZ9HB4JR86"
};
// Initialize Firebase with the configuration object.
// Initialize Firebase with the configuration object.
firebase.initializeApp(firebaseConfig);

var database = firebase.database();
var currentUserNameElement = document.getElementById("current-user-name");

// Function to update user information
function updateUserInformation(user) {
  if (user) {
    // User is logged in
    const userId = user.uid; // Assuming that the user object has a unique ID
    var userRef = database.ref("patients").child(userId);

    userRef.on("value", function (snapshot) {
      if (snapshot.exists()) {
        const patient = snapshot.val();
        var welcomeMessage = "Welcome " + patient.name;
        currentUserNameElement.textContent = welcomeMessage;
        console.log("Patient name:", welcomeMessage);
      } else {
        console.log("No data found for the current user.");
      }
    });
  }
}

// Add an observer for authentication state changes
firebase.auth().onAuthStateChanged(function (user) {
  updateUserInformation(user);
});

// You may also want to call updateUserInformation initially to handle the initial state
updateUserInformation(firebase.auth().currentUser);
