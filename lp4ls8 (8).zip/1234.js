import { initializeApp } from "firebase/app";
import { getAuth, onAuthStateChanged } from "firebase/auth";
import { getDatabase, ref } from "firebase/database";

const firebaseConfig = {
  apiKey: "AIzaSyATCPtybCzqCHhj4jFFFsDnSaM1vZT1_Dg",
  authDomain: "dvista-4da17.firebaseapp.com",
  databaseURL: "https://dvista-4da17-default-rtdb.firebaseio.com",
  projectId: "dvista-4da17",
  storageBucket: "dvista-4da17.appspot.com",
  messagingSenderId: "301281279487",
  appId: "1:301281279487:web:55a443aefa5f8c4696fbca",
  measurementId: "G-ZZ9HB4JR86"
};
s;

const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);
const db = getDatabase(firebaseApp);

const emailElement = document.getElementById("abc"); // Change the ID to match your HTML

function setEmail(element, email) {
  element.textContent = email;
}

onAuthStateChanged(auth, (user) => {
  if (user) {
    // User is signed in.
    const userEmail = user.email;

    // Set the content of the emailElement to the user's email
    setEmail(emailElement, userEmail);
  } else {
    // User is signed out.
    // You can handle this case here, e.g., redirect to a login page.
  }
});
