// Initialize Firebase
const firebaseConfig = {
  apiKey: "AIzaSyATCPtybCzqCHhj4jFFFsDnSaM1vZT1_Dg",
  authDomain: "dvista-4da17.firebaseapp.com",
  databaseURL: "https://dvista-4da17-default-rtdb.firebaseio.com",
  projectId: "dvista-4da17",
  storageBucket: "dvista-4da17.appspot.com",
  messagingSenderId: "301281279487",
  appId: "1:301281279487:web:55a443aefa5f8c4696fbca",
  measurementId: "G-ZZ9HB4JR86"
};

// Function to fetch and display all patient records
async function fetchAndDisplayAllPatientRecords() {
  // Clear the patient table
  const patientTable = document.getElementById("patientTable");
  patientTable.innerHTML = "";

  // Create a reference to the "patients" collection in Firebase
  const patientsRef = firebase.collection(firestore, "patients");

  // Get all documents in the patients collection
  const querySnapshot = await firebase.getDocs(patientsRef);

  // Display all patient records in your HTML
  querySnapshot.forEach((doc) => {
    const data = doc.data();
    const row = document.createElement("tr");
    row.innerHTML = `
          <td>${data.name}</td>
          <td>${data.email}</td>
          <td>${data.city}</td>
          <td>
              <span><i class="ri-edit-line edit"></i><i class="ri-delete-bin-line delete"></i></span>
          </td>
      `;
    patientTable.appendChild(row);
  });
}

// Function to fetch and display all dentist records
async function fetchAndDisplayAllDentistRecords() {
  // Clear the dentist table
  const dentistTable = document.getElementById("dentistTable");
  dentistTable.innerHTML = "";

  // Create a reference to the "dentists" collection in Firebase
  const dentistsRef = firebase.collection(firestore, "dentists");

  // Get all documents in the dentists collection
  const querySnapshot = await firebase.getDocs(dentistsRef);

  // Display all dentist records in your HTML
  querySnapshot.forEach((doc) => {
    const data = doc.data();
    const row = document.createElement("tr");
    row.innerHTML = `
          <td>${data.name}</td>
          <td>${data.gender}</td>
          <td>${data.status}</td>
          <td>
              <span><i class="ri-edit-line edit"></i><i class="ri-delete-bin-line delete"></i></span>
          </td>
      `;
    dentistTable.appendChild(row);
  });
}

// ...

// Fetch and display all patient and dentist records
fetchAndDisplayAllPatientRecords();
fetchAndDisplayAllDentistRecords();
