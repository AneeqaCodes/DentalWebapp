// Firebase configuration object obtained from Firebase console
// Import the functions you need from the SDKs you need
import { firebase } from "https://www.gstatic.com/firebasejs/9.21.0/firebase-app.js";

const firebaseConfig = {
  apiKey: "AIzaSyD8kZ5gClc3Hhl2V24X7MQbB5WHkn9WJDE",
  authDomain: "dentalvista-1899c.firebaseapp.com",
  databaseURL: "https://dentalvista-1899c-default-rtdb.firebaseio.com",
  projectId: "dentalvista-1899c",
  storageBucket: "dentalvista-1899c.appspot.com",
  messagingSenderId: "1029043026885",
  appId: "1:1029043026885:web:756cf4d5ce2aa91cc3e9ac",
  measurementId: "G-SZJKZ7JQDB"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const database = firebase.database();

function populateDentists() {
  const dentistSelect = document.getElementById("dentist");

  // Fetch the dentists data from Firebase
  database
    .ref("dentists")
    .once("value")
    .then((snapshot) => {
      snapshot.forEach((dentistSnapshot) => {
        const dentistKey = dentistSnapshot.key;
        const dentistName = dentistSnapshot.child("name").val();

        // Create and append option elements to the select dropdown
        const option = document.createElement("option");
        option.value = dentistKey;
        option.textContent = dentistName;
        dentistSelect.appendChild(option);
      });
    });
}

function submitForm() {
  const name = document.getElementById("name").value;
  const phoneNumber = document.getElementById("phoneNumber").value;
  const email = document.getElementById("email").value;
  const date = document.getElementById("date").value;
  const time = document.getElementById("time").value;
  const dentist = document.getElementById("dentist").value;
  const comments = document.getElementById("comments").value;

  // Perform form validation here using regular expressions
  // Save the data to Firebase database
  database
    .ref("appointments")
    .push({
      name: name,
      phoneNumber: phoneNumber,
      email: email,
      date: date,
      time: time,
      dentist: dentist,
      comments: comments
    })
    .then(() => {
      // Redirect to the payment page after successful form submission
      window.location.href = "payment.html";
    })
    .catch((error) => {
      console.error("Error saving data: ", error);
      // Handle error cases if needed
    });
}

window.onload = function () {
  populateDentists();
};
