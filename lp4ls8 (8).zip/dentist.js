const firebaseConfig = {
  apiKey: "AIzaSyATCPtybCzqCHhj4jFFFsDnSaM1vZT1_Dg",
  authDomain: "dvista-4da17.firebaseapp.com",
  databaseURL: "https://dvista-4da17-default-rtdb.firebaseio.com",
  projectId: "dvista-4da17",
  storageBucket: "dvista-4da17.appspot.com",
  messagingSenderId: "301281279487",
  appId: "1:301281279487:web:55a443aefa5f8c4696fbca",
  measurementId: "G-ZZ9HB4JR86"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
var database = firebase.database();
var auth = firebase.auth();

// Handle form submission
const dentistSignUpForm = document.getElementById("signup-form");
dentistSignUpForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  // Fetch form data
  const name = document.getElementById("dentistName").value;
  const email = document.getElementById("dentistEmail").value;
  const password = document.getElementById("dentistPassword").value;
  const city = document.getElementById("dentistCity").value;
  const designation = document.getElementById("dentistDesignation").value;

  // Get the "From Time" and "To Time" values
  const fromTime = document.getElementById("fromTimeInput").value;
  const toTime = document.getElementById("toTimeInput").value;

  // Add code to get other form fields and checkboxes

  // --- Implement Custom Data Validation Logic ---

  if (
    !isValidData(name, email, password, city, designation, fromTime, toTime)
  ) {
    alert("Invalid data format or criteria");
    return;
  }

  // --- Firebase Sign-Up Logic for Dentists ---

  try {
    firebase
      .auth()
      .createUserWithEmailAndPassword(email, password)
      .then(function (userCredential) {
        // Sign-up successful
        var user = userCredential.user;

        // Now, you can add dentist data to the Firebase Realtime Database
        const userData = {
          name: name,
          email: email,
          city: city,
          designation: designation,
          // Add other fields and checkboxes here
          experience: document.getElementById("dentistLicense").value,
          phone: document.getElementById("dentistPhone").value,
          mondaySelected: document.getElementById("monday").checked,
          tuesdaySelected: document.getElementById("tuesday").checked,
          wednesdaySelected: document.getElementById("wednesday").checked,
          thursdaySelected: document.getElementById("thursday").checked,
          fridaySelected: document.getElementById("friday").checked,
          saturdaySelected: document.getElementById("saturday").checked,
          sundaySelected: document.getElementById("sunday").checked,
          fromTime: fromTime, // Include "From Time"
          toTime: toTime // Include "To Time"
        };

        // Reference to the Firebase database
        var databaseRef = firebase.database().ref("dentists/" + user.uid);

        // Set the data in the Firebase Realtime Database
        databaseRef.set(userData, function (error) {
          if (error) {
            console.log("Data could not be saved:", error);
            alert("Sign up failed. Please try again.");
          } else {
            console.log("Data saved successfully.");
            alert("Sign up successful");
            window.location.href = "admin.html"; // Redirect to the admin page
          }
        });
      })
      .catch(function (error) {
        // Handle Firebase sign-up errors
        var errorCode = error.code;
        var errorMessage = error.message;
        console.log("Firebase Sign-up failed: " + errorMessage);
        alert("Sign-up failed: " + errorMessage);
      });
  } catch (error) {
    console.error("Sign up failed: " + error.message);
  }
});

// Implement your custom data validation logic here
function isValidData(
  name,
  email,
  password,
  city,
  designation,
  fromTime,
  toTime
) {
  // Implement your custom data validation logic here
  // For example, you can use regular expressions to validate fields
  // Return true if the data meets your criteria
  return (
    name.trim() !== "" &&
    isValidEmail(email) &&
    isValidPassword(password) &&
    city.trim() !== "" &&
    designation.trim() !== "" &&
    fromTime.trim() !== "" &&
    toTime.trim() !== ""
  );
}

// Function to check if the email format is valid
function isValidEmail(email) {
  // Implement your email validation logic here, e.g., using regular expressions
  return /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/.test(email);
}

// Function to check if the password format is valid
function isValidPassword(password) {
  // Implement your password validation logic here, e.g., using regular expressions
  return /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(
    password
  );
}
