import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/9.6.10/firebase-analytics.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword
} from "https://www.gstatic.com/firebasejs/9.6.10/firebase-auth.js";
import {
  getDatabase,
  ref,
  push,
  orderByChild,
  equalTo
} from "https://www.gstatic.com/firebasejs/9.6.10/firebase-database.js";
const firebaseConfig = {
  apiKey: "AIzaSyATCPtybCzqCHhj4jFFFsDnSaM1vZT1_Dg",
  authDomain: "dvista-4da17.firebaseapp.com",
  databaseURL: "https://dvista-4da17-default-rtdb.firebaseio.com",
  projectId: "dvista-4da17",
  storageBucket: "dvista-4da17.appspot.com",
  messagingSenderId: "301281279487",
  appId: "1:301281279487:web:55a443aefa5f8c4696fbca",
  measurementId: "G-ZZ9HB4JR86"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

const submitButton = document.getElementById("submit");
const signupButton = document.getElementById("sign-up");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const main = document.getElementById("main");
const createacct = document.getElementById("create-acct");
const userGreeting = document.getElementById("user-greeting");

const signupEmailIn = document.getElementById("email-signup");
const name = document.getElementById("name");
const signupPasswordIn = document.getElementById("password-signup");
const confirmSignUpPasswordIn = document.getElementById(
  "confirm-password-signup"
);
const createacctbtn = document.getElementById("create-acct-btn");

const returnBtn = document.getElementById("return-btn");

createacctbtn.addEventListener("click", function () {
  var isVerified = true;
  const signupEmail = signupEmailIn.value;
  const Name = name.value;
  const signupPassword = signupPasswordIn.value;
  const confirmSignUpPassword = confirmSignUpPasswordIn.value;

  if (signupPassword != confirmSignUpPassword) {
    window.alert("Password fields do not match. Try again.");
    isVerified = false;
  }

  if (
    signupEmail == "" ||
    Name == "" ||
    signupPassword == "" ||
    confirmSignUpPassword == ""
  ) {
    window.alert("Please fill out all required fields.");
    isVerified = false;
  }

  if (isVerified) {
    createUserWithEmailAndPassword(auth, signupEmail, signupPassword)
      .then((userCredential) => {
        // Signed in
        window.alert("Success! Account created.");
        window.location.href = "patient.html";
      })
      .catch((error) => {
        window.alert("Error occurred. Try again.");
      });
  }
});

submitButton.addEventListener("click", function () {
  const email = emailInput.value;
  const password = passwordInput.value;

  if (email === "admin66@admin.com" && password === "admin") {
    // Redirect to the admin.html page
    window.location.href = "admin.html";
  } else {
    signInWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        // Signed in
        // Fetch user's name from the database and display a welcome message
        fetchUserName(email);
      })
      .catch((error) => {
        window.alert("Error occurred. Try again.");
      });
  }
});

function fetchUserName(email) {
  const usersRef = ref(db, "users");
  orderByChild(usersRef, "email")
    .equalTo(email)
    .once("value", (snapshot) => {
      snapshot.forEach((user) => {
        const userData = user.val();
        const userName = userData.name;
        userGreeting.textContent = `Welcome, ${userName}!`;
      });
    });
}

signupButton.addEventListener("click", function () {
  main.style.display = "none";
  createacct.style.display = "block";
});

returnBtn.addEventListener("click", function () {
  main.style.display = "block";
  createacct.style.display = "none";
});
